#pragma once
#include "CoreMinimal.h"

typedef TSharedPtr<struct FSVONNavigationPath, ESPMode::ThreadSafe> FSVONNavPathSharedPtr;