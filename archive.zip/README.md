# uesvon
3D navigation plugin for UnrealEngine

Engine Version : Tested with 4.21 and 4.20. Should work with earlier versions.

Please view the [Wiki](https://github.com/midgen/uesvon/wiki) for more information

[![UESVON Demo](http://img.youtube.com/vi/84AFdg0ykwY/0.jpg)](http://www.youtube.com/watch?v=84AFdg0ykwY "Video Title")


